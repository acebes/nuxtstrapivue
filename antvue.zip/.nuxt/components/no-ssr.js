/*
** From https://github.com/egoist/vue-no-ssr
** With the authorization of @egoist
*/
import NoSSR from 'vue-no-ssr'
export default NoSSR
